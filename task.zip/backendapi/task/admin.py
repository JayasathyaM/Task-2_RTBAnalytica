from django.contrib import admin
from .models import Company, CompanyPosting, User, UserApplycompany, UserApplyuser

# Register your models here.
admin.site.register(Company)
admin.site.register(CompanyPosting)
admin.site.register(User)
admin.site.register(UserApplycompany)
admin.site.register(UserApplyuser)
