import json
from django.shortcuts import render
from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework import status
from .models import Company, CompanyPosting, User, UserApplycompany, UserApplyuser


# Create your views here.
class CompanySignup(APIView):
    @staticmethod
    def post(request):
        companydata = json.loads(request.body)
        company = Company(companyName=companydata["name"],
                          companyEmail=companydata["email"],
                          companyPassword=companydata["password"])
        try:
            existingcompany = Company.objects.get(companyEmail=company.companyEmail)
            if existingcompany:
                return HttpResponse("Company with given mail id already exists", status=status.HTTP_400_BAD_REQUEST)
        except:
            pass
        company.save()
        return HttpResponse("Company Details saved Successfully", status=status.HTTP_200_OK)


class CompanySignin(APIView):
    @staticmethod
    def get(request):
        companydata = json.loads(request.body)
        try:
            companydetails = Company.objects.get(companyEmail=companydata["email"])
            if companydetails.companyPassword == companydata["password"]:
                return HttpResponse("Logged in Successfully", status=status.HTTP_200_OK)
            else:
                return HttpResponse("Invalid email or password", status=status.HTTP_400_BAD_REQUEST)
        except:
            return HttpResponse("Invalid email or password", status=status.HTTP_400_BAD_REQUEST)


class CompanyJobPosting(APIView):
    @staticmethod
    def post(request):
        jobposts = json.loads(request.body)
        try:
            company = Company.objects.get(companyEmail=jobposts["email"])
            company.companyposting_set.create(jobtitle=jobposts["title"],
                                              experience=jobposts["experience"],
                                              salaryRange=jobposts["salary"],
                                              skillset=jobposts["skill"])
            return HttpResponse(f"Job post created by {company.companyName}")
        except:
            return HttpResponse("Invalid Email", status=status.HTTP_400_BAD_REQUEST)


class UserSignup(APIView):
    @staticmethod
    def post(request):
        userdata = json.loads(request.body)
        user = User(username=userdata["name"],
                    useremail=userdata["email"],
                    userpassword=userdata["password"],
                    phonenumber=userdata["phonenumber"],
                    linkedinurl=userdata["linkedinurl"],
                    resume=userdata["resume"])
        try:
            existinguser = User.objects.get(useremail=user.useremail)
            if existinguser:
                return HttpResponse("User with given mail id already exists", status=status.HTTP_400_BAD_REQUEST)
        except:
            pass
        user.save()
        return HttpResponse("User Details saved Successfully", status=status.HTTP_200_OK)


class UserSignin(APIView):
    @staticmethod
    def get(request):
        userdata = json.loads(request.body)
        try:
            userdetails = User.objects.get(useremail=userdata["email"])
            if userdetails.userpassword == userdata["password"]:
                return HttpResponse("Logged in Successfully", status=status.HTTP_200_OK)
            else:
                return HttpResponse("Invalid email or password", status=status.HTTP_400_BAD_REQUEST)
        except:
            return HttpResponse("Invalid email or password", status=status.HTTP_400_BAD_REQUEST)


class JobApply(APIView):
    @staticmethod
    def post(request):
        # useremail, companyemail, jobtitle
        job = json.loads(request.body)
        try:
            user = User.objects.get(useremail=job["useremail"])
            company = Company.objects.get(companyEmail=job["companyemail"])
            jobposted = company.companyposting_set.get(jobtitle=job["jobtitle"])
            user.userapplyuser_set.create(username=user.username,
                                          useremail=user.useremail,
                                          phonenumber=user.phonenumber,
                                          linkedinurl=user.linkedinurl,
                                          resume=user.resume,
                                          appliedto=company.companyName,
                                          role=job["jobtitle"])
            company.userapplycompany_set.create(username=user.username,
                                                useremail=user.useremail,
                                                phonenumber=user.phonenumber,
                                                linkedinurl=user.linkedinurl,
                                                resume=user.resume,
                                                role=job["jobtitle"])
            return HttpResponse("User Applied for the Job and Company notified Successfully.",
                                status=status.HTTP_200_OK)
        except:
            return HttpResponse("Invalid Usermail or Companymail or Requested Job title not available",
                                status=status.HTTP_400_BAD_REQUEST)
