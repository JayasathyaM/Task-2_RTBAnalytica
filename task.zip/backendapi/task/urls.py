from django.urls import path
from . import views

urlpatterns = [
    path("company/signup", views.CompanySignup.as_view()),
    path("company/signin", views.CompanySignin.as_view()),
    path("company/posts", views.CompanyJobPosting.as_view()),
    path("user/signup", views.UserSignup.as_view()),
    path("user/signin", views.UserSignin.as_view()),
    path("user/apply", views.JobApply.as_view()),
]
