from django.db import models


# Create your models here.
class Company(models.Model):
    companyName = models.CharField(max_length=50)
    companyPassword = models.CharField(max_length=50)
    companyEmail = models.CharField(max_length=50)

    def __str__(self):
        return self.companyName


class CompanyPosting(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    jobtitle = models.CharField(max_length=100)
    experience = models.CharField(max_length=50)
    salaryRange = models.CharField(max_length=100)
    skillset = models.CharField(max_length=100)

    def __str__(self):
        return self.jobtitle


class User(models.Model):
    username = models.CharField(max_length=50)
    useremail = models.CharField(max_length=50)
    userpassword = models.CharField(max_length=50)
    phonenumber = models.CharField(max_length=20)
    linkedinurl = models.CharField(max_length=100)
    resume = models.CharField(max_length=100)

    def __str__(self):
        return self.username


class UserApplycompany(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    username = models.CharField(max_length=50)
    useremail = models.CharField(max_length=50)
    phonenumber = models.CharField(max_length=20)
    linkedinurl = models.CharField(max_length=100)
    resume = models.CharField(max_length=100)
    role = models.CharField(max_length=100)

    def __str__(self):
        return self.username


class UserApplyuser(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    username = models.CharField(max_length=50)
    useremail = models.CharField(max_length=50)
    phonenumber = models.CharField(max_length=20)
    linkedinurl = models.CharField(max_length=100)
    resume = models.CharField(max_length=100)
    appliedto = models.CharField(max_length=100)
    role = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.username} applied to {self.appliedto}"
